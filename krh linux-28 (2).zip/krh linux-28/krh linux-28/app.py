import os
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from flask_wtf import FlaskForm, CSRFProtect
from wtforms import StringField, DateField, TimeField
from wtforms.validators import DataRequired, Email
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import smtplib
import random
from datetime import datetime, timedelta, timezone
import mysql.connector
import logging
from mysql.connector import Error
from typing import Optional, Dict, Any
from flask_mysqldb import MySQL
import json
from flask_wtf.csrf import CSRFProtect, generate_csrf
from dotenv import load_dotenv
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

from flask import Response, stream_with_context
import json
import queue
import threading



# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'fallback_secret_key')

# Create base directory for logs
BASE_DIR = Path(__file__).resolve().parent
LOG_DIR = BASE_DIR / 'logs'
LOG_DIR.mkdir(exist_ok=True, parents=True)

# Set up logging with proper permissions
log_file = LOG_DIR / 'app.log'
handler = RotatingFileHandler(
    str(log_file),
    maxBytes=10000000,  # 10MB
    backupCount=5,
    mode='a'  # Append mode
)
handler.setFormatter(logging.Formatter(
    '%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
))
app.logger.addHandler(handler)
app.logger.setLevel(logging.INFO)

# Ensure log file has correct permissions
try:
    log_file.chmod(0o644)  # User read/write, group/others read
except Exception as e:
    app.logger.warning(f"Could not set log file permissions: {e}")

# MySQL connection configuration using environment variables
def get_db_connection():
    return mysql.connector.connect(
        host=os.getenv('MYSQL_HOST', 'localhost'),
        user=os.getenv('MYSQL_USER', 'root'),
        password=os.getenv('MYSQL_PASSWORD', 'mysql123'),
        database=os.getenv('MYSQL_DATABASE', 'krh'),
        port=int(os.getenv('MYSQL_PORT', '3306'))
    )

# Load admin credentials from environment variables
ADMIN_EMAIL = os.getenv('ADMIN_EMAIL', 'drkrhomeo23@gmail.com')
ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD', 'pbkdf2:sha256:260000$zL8RqeUT1KXa9A9c$d888330c3e2fb3e495726710bd6573ce6599a7738eb9645dd25061e9b6c772fd')

# Email configuration from environment variables
SMTP_SERVER = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
SMTP_PORT = int(os.getenv('SMTP_PORT', '587'))
SMTP_USERNAME = os.getenv('SMTP_USERNAME', 'krhomeocareteam@gmail.com')
SMTP_PASSWORD = os.getenv('SMTP_PASSWORD', 'pfwh chpb ewko mlsd')

# CSRF protection
csrf = CSRFProtect(app)

@app.route('/get-csrf-token', methods=['GET'])
def get_csrf_token():
    token = generate_csrf()
    return jsonify({'csrf_token': token})


#''''''''''''''''''''''''''''''''''''''''''''''''''''''''''OTP GENERATION''''''''''''''''''''''''''''''''''''''''''''''''''''''''''#


def generate_otp(length=6):
    return ''.join([str(random.randint(0, 9)) for _ in range(length)])

def send_otp(email, otp):
    try:
        sender_email = SMTP_USERNAME
        sender_password = SMTP_PASSWORD

        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = email
        msg['Subject'] = "Your OTP Verification Code"

        body = f'Your OTP verification code is {otp}. Please use this to verify your account.'
        msg.attach(MIMEText(body, 'plain'))

        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(sender_email, sender_password)
        server.send_message(msg)
        
        app.logger.info(f'OTP sent successfully to {email}')
        return True

    except Exception as e:
        app.logger.error(f'Failed to send OTP: {str(e)}')
        return False
    finally:
        if 'server' in locals():
            server.quit()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('home'))
        return f(*args, **kwargs)
    return decorated_function

def admin_login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_id' not in session:
            return redirect(url_for('patient_login'))
        return f(*args, **kwargs)
    return decorated_function



#.......................................LOGIN/SIGNUP SYSTEM .........................................................................



# Patient routes
@app.route('/')
def home():
    return render_template('home.html')


@app.route('/submit_contact', methods=['POST'])
def submit_contact():
    if request.method != 'POST':
        flash('Invalid request method', 'danger')
        return redirect(url_for('home'))
    
    try:
        # Retrieve form data with get() for safer access
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        message = request.form.get('message')
        
        # Validate required fields
        if not all([name, email, message]):
            flash('Please fill in all required fields', 'warning')
            return redirect(url_for('home'))
        
        # Log form data for debugging
        app.logger.info(
            f"Received form data: Name={name}, Email={email}, "
            f"Phone={phone}, Message={message}"
        )
        
        # Database operations
        try:
            connection = get_db_connection()
            cursor = connection.cursor()
            
            # Modified query to match the table structure
            query = """
                INSERT INTO contacts (name, email, phone, message)
                VALUES (%s, %s, %s, %s)
            """
            cursor.execute(query, (name, email, phone, message))
            
            # Get the ID of the inserted record
            message_id = cursor.lastrowid
            connection.commit()
            
            # Prepare notification data
            notification_data = {
                'id': message_id,
                'name': name,
                'email': email,
                'message': message[:50] + '...' if len(message) > 50 else message,
                'type': 'new_message',
                'timestamp': datetime.now().isoformat()
            }
            
            # Add to message queue for real-time notifications
            if hasattr(app, 'message_queue'):
                app.message_queue.put(notification_data)
            
            # Start email notification in separate thread
            threading.Thread(
                target=send_email_notification,
                args=(name, email, phone, message),
                daemon=True
            ).start()
            
            flash('Thank you for choosing us, we will contact you soon!', 'success')
            
        except Error as db_error:
            app.logger.error(f"Database error: {db_error}")
            flash('An error occurred while processing your request.', 'danger')
            raise
            
    except Exception as e:
        app.logger.error(f"Error in submit_contact: {str(e)}")
        flash('There was an issue submitting your form. Please try again later.', 'danger')
    
    finally:
        # Ensure database connections are properly closed
        if 'cursor' in locals():
            cursor.close()
        if 'connection' in locals():
            connection.close()
    
    return redirect(url_for('home'))


@app.route('/patient_login', methods=['GET', 'POST'])
def patient_login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        # Check if the credentials match the admin credentials
        if email == ADMIN_EMAIL and check_password_hash(ADMIN_PASSWORD, password):
            session['admin_id'] = email
            return jsonify({'success': True, 'message': 'Admin login successful!', 'redirect': url_for('admin_dashboard')})
        
        # If not admin, proceed with regular patient login
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("SELECT * FROM users WHERE email=%s", (email,))
        user_data = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if not user_data:
            return jsonify({'success': False, 'message': 'User not found. Please check your email or sign up.'})
        
        if not check_password_hash(user_data['password'], password):
            return jsonify({'success': False, 'message': 'Incorrect password. Please try again.'})
        
        session['user_id'] = email
        return jsonify({'success': True, 'message': 'Login successful!', 'redirect': url_for('patient_dashboard')})
    else:
        return render_template('patient_login.html')


@app.route('/patient_signup', methods=['POST']) 
def patient_signup():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    confirm_password = data.get('confirm_password')
    username = data.get('username') 

    if password != confirm_password:
        return jsonify({'success': False, 'message': 'Passwords do not match'})

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT email FROM users WHERE email=%s", (email,))
    if cursor.fetchone():
        cursor.close()
        conn.close()
        return jsonify({'success': False, 'message': 'Email already registered'})
       
    cursor.execute("SELECT username FROM users WHERE username=%s", (username,))
    if cursor.fetchone():
        cursor.close()
        conn.close()
        return jsonify({'success': False, 'message': 'Username already taken'})

    hashed_password = generate_password_hash(password)
    otp = generate_otp()

    # Use datetime.now(timezone.utc) instead of datetime.utcnow()
    otp_expiry = (datetime.now(timezone.utc) + timedelta(minutes=10)).isoformat()

    cursor.execute(
        "INSERT INTO users (email, password, otp, otp_expiry, username) VALUES (%s, %s, %s, %s, %s)",
        (email, hashed_password, otp, otp_expiry, username) 
    )
    conn.commit()
    cursor.close()
    conn.close()

    if send_otp(email, otp):
        session['signup_email'] = email
        return jsonify({'success': True, 'message': 'OTP sent to your email address'})
    else:
        return jsonify({'success': False, 'message': 'Failed to send OTP. Please try again.'})


@app.route('/verify_patient_otp', methods=['POST'])
def verify_patient_otp():
    entered_otp = request.form['otp']
    email = session.get('signup_email')

    if not email:
        logging.warning(f"Attempt to verify OTP without a signup email in session")
        return jsonify({'success': False, 'message': 'Invalid session. Please start the signup process again.'})

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT otp, otp_expiry FROM users WHERE email=%s", (email,))
        user_data = cursor.fetchone()
    except mysql.connector.Error as err:
        logging.error(f"Database error: {err}")
        return jsonify({'success': False, 'message': 'An error occurred. Please try again later.'})
    finally:
        cursor.close()
        conn.close()

    if not user_data:
        logging.warning(f"No user found for email: {email}")
        return jsonify({'success': False, 'message': 'Invalid user. Please start the signup process again.'})

    try:
        otp_expiry = user_data['otp_expiry']
        if isinstance(otp_expiry, datetime):
            otp_expiry = otp_expiry.isoformat()
        
        otp_expiry_dt = datetime.fromisoformat(otp_expiry).replace(tzinfo=timezone.utc)
        
        if otp_expiry_dt <= datetime.now(timezone.utc):
            logging.info(f"OTP expired for user: {email}")
            return jsonify({'success': False, 'message': 'OTP expired. Please request a new one.'})

        if user_data['otp'] != entered_otp:
            logging.warning(f"Invalid OTP entered for user: {email}")
            return jsonify({'success': False, 'message': 'Invalid OTP. Please try again.'})

        # OTP is valid, update user record
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET otp=NULL, otp_expiry=NULL WHERE email=%s", (email,))
        conn.commit()

        # Store login details in the session
        session['user_id'] = email
        session['logged_in'] = True
        logging.info(f"User logged in successfully: {email}")
        return jsonify({'success': True, 'message': 'Login successful!'})

    except ValueError as ve:
        logging.error(f"ValueError in OTP verification: {ve}")
        return jsonify({'success': False, 'message': 'An error occurred. Please try again later.'})
    except Exception as e:
        logging.error(f"Unexpected error in OTP verification: {e}")
        return jsonify({'success': False, 'message': 'An unexpected error occurred. Please try again later.'})

@app.route('/patient_dashboard')
@login_required
def patient_dashboard():
    email = session['user_id']
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Make sure to explicitly convert id to integer
        cursor.execute("SELECT id, username, email FROM users WHERE email=%s", (email,))
        user_data = cursor.fetchone()
        
        # Ensure user_data contains valid integer ID
        if user_data and user_data['id']:
            user_data['id'] = int(user_data['id'])
        
        cursor.close()
        conn.close()
        
        if not user_data:
            flash('User not found. Please log in again.', 'danger')
            return redirect(url_for('patient_login'))
        
        # Add default doctor ID
        doctor_id = 1  # Replace with your actual doctor ID
        return render_template('patient_dashboard.html', user=user_data, doctor_id=doctor_id)
        
    except Exception as e:
        app.logger.error(f"Error in patient_dashboard: {str(e)}")
        flash('An error occurred while fetching your information.', 'danger')
        return redirect(url_for('patient_dashboard'))

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('home'))




#...........................................................admin route...............................................................


@app.route('/admin_dashboard')
@admin_login_required
def admin_dashboard():
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get appointment count
        cursor.execute("SELECT COUNT(*) as count FROM appointments")
        appointment_count = cursor.fetchone()['count']
        
        # Get patient count
        cursor.execute("SELECT COUNT(*) as count FROM users")
        patient_count = cursor.fetchone()['count']
        
        # Get doctor count
        cursor.execute("SELECT COUNT(*) as count FROM doctors")
        doctor_count = cursor.fetchone()['count']
        
        cursor.close()
        conn.close()
        
        return render_template('admin_dashboard.html', 
                               appointment_count=appointment_count,
                               patient_count=patient_count,
                               doctor_count=doctor_count)
    except mysql.connector.Error as err:
        flash(f'Database error: {str(err)}', 'error')
        return render_template('admin_dashboard.html', 
                               appointment_count=0,
                               patient_count=0,
                               doctor_count=0)





@app.route('/admin_logout')
def admin_logout():
    session.pop('admin_id', None)
    return redirect(url_for('home'))


@app.route('/appointments_history')
@login_required
def appointments_history():
    try:
        # Get current user's email from session
        email = session['user_id']
        
        # Connect to database
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Fetch all appointments for the current user
        cursor.execute("""
            SELECT * FROM appointments 
            WHERE email = %s 
            ORDER BY date DESC, time DESC
        """, (email,))
        
        appointments = cursor.fetchall()
        
        # Close database connection
        cursor.close()
        conn.close()
        
        return render_template('appointments_history.html', 
                             appointments=appointments,
                             current_user={'email': email})
                             
    except Exception as e:
        app.logger.error(f"Error in appointments_history: {str(e)}")
        flash('An error occurred while fetching your appointments.', 'danger')
        return redirect(url_for('patient_dashboard'))








#'''''''''''''''''''''''''''''''''''''''''''''''''''''''''APPOINTMENT BOOKING ROUTE'''''''''''''''''''''''''''''''''''''#


class AppointmentForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    phone = StringField('Phone', validators=[DataRequired()])
    date = DateField('Date', validators=[DataRequired()])
    time = TimeField('Time', validators=[DataRequired()])

    def __init__(self, *args, **kwargs):
        super(AppointmentForm, self).__init__(*args, **kwargs)
        # Populate available time slots
        self.time.choices = self.get_available_times()

    def get_available_times(self):
        # Get all booked appointments for the selected date
        if self.date.data:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            
            cursor.execute("""
                SELECT TIME_FORMAT(time, '%H:%i') as time 
                FROM appointments 
                WHERE date = %s AND status != 'cancelled'
            """, (self.date.data.strftime('%Y-%m-%d'),))
            
            booked_times = {row['time'] for row in cursor.fetchall()}
            cursor.close()
            conn.close()

            # Generate all possible time slots (e.g., 9 AM to 5 PM, 30-minute intervals)
            all_slots = []
            start_time = datetime.strptime('08:00', '%H:%M')
            end_time = datetime.strptime('18:00', '%H:%M')
            slot = start_time
            
            while slot <= end_time:
                time_str = slot.strftime('%H:%M')
                if time_str not in booked_times:
                    all_slots.append((time_str, time_str))
                slot += timedelta(minutes=30)

            return all_slots
        return []

@app.route('/patient_appointment', methods=['GET', 'POST'])
def patient_appointment():
    form = AppointmentForm()
    
    if form.validate_on_submit():
        try:
            conn = get_db_connection()
            cursor = conn.cursor(dictionary=True)
            
            # Check if the time slot is still available
            cursor.execute("""
                SELECT COUNT(*) as count 
                FROM appointments 
                WHERE date = %s AND time = %s AND status != 'cancelled'
            """, (form.date.data.strftime('%Y-%m-%d'), form.time.data.strftime('%H:%M')))
            
            result = cursor.fetchone()
            if result['count'] > 0:
                flash('This time slot is no longer available. Please choose another time.', 'error')
                return redirect(url_for('patient_appointment'))

            # Convert form data to dict
            appointment_data = {
                'name': form.name.data,
                'email': form.email.data,
                'phone': form.phone.data,
                'date': form.date.data.strftime('%Y-%m-%d'),
                'time': form.time.data.strftime('%H:%M'),
                'status': 'confirmed'
            }
            
            # Save to MySQL database
            sql = """
                INSERT INTO appointments 
                (name, email, phone, date, time, status)
                VALUES (%s, %s, %s, %s, %s, %s)
            """
            values = (
                appointment_data['name'],
                appointment_data['email'],
                appointment_data['phone'],
                appointment_data['date'],
                appointment_data['time'],
                appointment_data['status']
            )
            
            cursor.execute(sql, values)
            conn.commit()
            
            # Send confirmation email
            try:
                send_confirmation_email(appointment_data)
            except Exception as e:
                flash('Appointment booked, but email confirmation failed.', 'warning')
                print(f"Email error: {str(e)}")
            else:
                flash('Appointment booked successfully!', 'success')
            
            return redirect(url_for('patient_appointment'))
            
        except mysql.connector.Error as err:
            flash(f'Database error: {str(err)}', 'error')
            return redirect(url_for('patient_appointment'))
            
        finally:
            if 'cursor' in locals():
                cursor.close()
            if 'conn' in locals():
                conn.close()
    
    return render_template('patient_appointment.html', form=form)

def get_available_slots(date):
    """Helper function to get available time slots for a given date"""
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("""
        SELECT TIME_FORMAT(time, '%H:%i') as time 
        FROM appointments 
        WHERE date = %s AND status != 'cancelled'
    """, (date,))
    
    booked_times = {row['time'] for row in cursor.fetchall()}
    cursor.close()
    conn.close()
    
    # Generate available time slots
    available_slots = []
    start_time = datetime.strptime('08:00', '%H:%M')
    end_time = datetime.strptime('18:00', '%H:%M')
    slot = start_time
    
    while slot <= end_time:
        time_str = slot.strftime('%H:%M')
        if time_str not in booked_times:
            available_slots.append(time_str)
        slot += timedelta(minutes=30)
    
    return available_slots




#'''''''''''''''''''''''''''''''''''''''''''''''''''''''''APPOINTMENT CONFIRMATION TO USER ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''




def send_confirmation_email(appointment_data):
    sender_email = "krhomeocareteam@gmail.com"
    sender_password = os.environ.get('EMAIL_PASSWORD', "pfwh chpb ewko mlsd")
    receiver_email = appointment_data['email']
    
    message = MIMEMultipart("alternative")
    message["Subject"] = "Appointment Confirmation"
    message["From"] = sender_email
    message["To"] = receiver_email
    
    text = f"""
    Dear {appointment_data['name']},
    
    Your appointment has been confirmed for {appointment_data['date']} at {appointment_data['time']}.
    
    Thank you for choosing our service.
    """
    
    part1 = MIMEText(text, "plain")
    message.attach(part1)

   
    with smtplib.SMTP("smtp.gmail.com", 587) as server:
        server.starttls()  
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, receiver_email, message.as_string())




#''''''''''''''''''''''''''''''''''''''''''''''''''''ADMIN APPOINTMENT''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''#

@app.route('/appointments')
def appointments():
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM appointments ORDER BY date, time")
        appointments_list = cursor.fetchall()
        cursor.close()
        conn.close()
    except mysql.connector.Error as err:
        flash(f'Error fetching appointments: {str(err)}', 'error')
        appointments_list = []
    
    return render_template('appointments.html', appointments=appointments_list)


@app.route('/update_appointment', methods=['POST'])
def update_appointment():
    form = AppointmentForm()
    if form.validate_on_submit():
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            
            sql = """
                UPDATE appointments 
                SET name = %s, email = %s, phone = %s, date = %s, time = %s
                WHERE id = %s
            """
            values = (
                form.name.data,
                form.email.data,
                form.phone.data,
                form.date.data.strftime('%Y-%m-%d'),
                form.time.data.strftime('%H:%M'),
                request.form.get('id')
            )
            
            cursor.execute(sql, values)
            conn.commit()
            flash('Appointment updated successfully!', 'success')
        except mysql.connector.Error as err:
            flash(f'Error updating appointment: {str(err)}', 'error')
        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f'{field.capitalize()}: {error}', 'error')
    
    return redirect(url_for('appointments'))


@app.route('/delete_appointment/<int:appointment_id>', methods=['POST'])
def delete_appointment(appointment_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("DELETE FROM appointments WHERE id = %s", (appointment_id,))
        conn.commit()
        flash('Appointment deleted successfully!', 'success')
    except mysql.connector.Error as err:
        flash(f'Error deleting appointment: {str(err)}', 'error')
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
    
    return redirect(url_for('appointments'))






#''''''''''''''''''''''''''''''''''''''''''''''''''''''''''MANAGE DOCTORS''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''#


@app.route('/manage_doctors')
def manage_doctors():
    connection = get_db_connection()
    if connection:
        try:
            cursor = connection.cursor(dictionary=True)
            cursor.execute("SELECT * FROM doctors")
            doctors = cursor.fetchall()
            cursor.close()
            connection.close()
            return render_template('manage_doctors.html', doctors=doctors)
        except Error as e:
            flash(f"Database error: {str(e)}", 'error')
            return redirect(url_for('dashboard'))  # Assuming you have a dashboard page
        finally:
            if connection.is_connected():
                connection.close()
    
    flash("Unable to connect to the database", 'error')
    return redirect(url_for('dashboard'))


@app.route('/add_doctor', methods=['POST'])
def add_doctor():
    connection = get_db_connection()
    if connection:
        try:
            cursor = connection.cursor()
            query = """INSERT INTO doctors (first_name, last_name, specialty, phone_number, email) 
                       VALUES (%s, %s, %s, %s, %s)"""
            values = (
                request.form.get('first_name'),
                request.form.get('last_name'),
                request.form.get('specialty'),
                request.form.get('phone_number'),
                request.form.get('email')
            )
            cursor.execute(query, values)
            connection.commit()
            flash('Doctor added successfully', 'success')
        except Error as e:
            connection.rollback()
            flash(f"Database error: {str(e)}", 'error')
        finally:
            if connection.is_connected():
                cursor.close()
                connection.close()
    else:
        flash("Unable to connect to the database", 'error')
    return redirect(url_for('manage_doctors'))


@app.route('/edit_doctor/<int:id>', methods=['POST'])
def edit_doctor(id: int):
    connection = get_db_connection()
    if connection:
        try:
            cursor = connection.cursor()
            query = """UPDATE doctors SET first_name=%s, last_name=%s, specialty=%s, 
                       phone_number=%s, email=%s WHERE id=%s"""
            values = (
                request.form.get('first_name'),
                request.form.get('last_name'),
                request.form.get('specialty'),
                request.form.get('phone_number'),
                request.form.get('email'),
                id
            )
            cursor.execute(query, values)
            connection.commit()
            flash('Doctor updated successfully', 'success')
        except Error as e:
            connection.rollback()
            flash(f"Database error: {str(e)}", 'error')
        finally:
            if connection.is_connected():
                cursor.close()
                connection.close()
    else:
        flash("Unable to connect to the database", 'error')
    return redirect(url_for('manage_doctors'))


@app.route('/delete_doctor/<int:id>', methods=['POST'])
def delete_doctor(id: int):
    connection = get_db_connection()
    if connection:
        try:
            cursor = connection.cursor()
            query = "DELETE FROM doctors WHERE id = %s"
            cursor.execute(query, (id,))
            connection.commit()
            flash('Doctor deleted successfully', 'success')
        except Error as e:
            connection.rollback()
            flash(f"Database error: {str(e)}", 'error')
        finally:
            if connection.is_connected():
                cursor.close()
                connection.close()
    else:
        flash("Unable to connect to the database", 'error')
    return redirect(url_for('manage_doctors'))



#''''''''''''''''''''''''''''''''''''''contact-info'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''#

@app.route('/admin_chat')
def admin_chat():
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        
        # Fetch messages from the contacts table
        cursor.execute("""
            SELECT id, name, email, phone, message, submission_date
            FROM contacts
            ORDER BY submission_date DESC
        """)
        
        messages = cursor.fetchall()
        
        # Convert submission_date to datetime object if it's not already
        for message in messages:
            if isinstance(message['submission_date'], str):
                message['submission_date'] = datetime.strptime(
                    message['submission_date'], 
                    '%Y-%m-%d %H:%M:%S'
                )
        
        app.logger.info("Successfully fetched messages for admin chat")
        return render_template('admin_chat.html', messages=messages)

    except mysql.connector.Error as err:
        app.logger.error(f"Database error in admin_chat: {err}")
        flash("An error occurred while fetching messages.", "error")
        return render_template('admin_chat.html', messages=[])
        
    except Exception as e:
        app.logger.error(f"Unexpected error in admin_chat: {e}")
        flash("An unexpected error occurred.", "error")
        return render_template('admin_chat.html', messages=[])
        
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'connection' in locals():
            connection.close()

@app.route('/message/<int:message_id>/status', methods=['POST'])
def update_message_status(message_id):
    try:
        status = request.form.get('status')
        if not status:
            raise ValueError("Status is required")

        connection = get_db_connection()
        cursor = connection.cursor()
        
        cursor.execute("""
            UPDATE contacts 
            SET status = %s 
            WHERE id = %s
        """, (status, message_id))
        
        connection.commit()
        app.logger.info(f"Successfully updated status for message {message_id} to {status}")
        flash("Message status updated successfully.", "success")

    except mysql.connector.Error as err:
        app.logger.error(f"Database error in update_message_status: {err}")
        flash("An error occurred while updating the message status.", "error")
        
    except Exception as e:
        app.logger.error(f"Unexpected error in update_message_status: {e}")
        flash("An unexpected error occurred.", "error")
        
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'connection' in locals():
            connection.close()
            
    return redirect(url_for('admin_chat'))

@app.route('/message/<int:message_id>/delete', methods=['POST'])
def delete_message(message_id):
    try:
        connection = get_db_connection()
        cursor = connection.cursor()
        
        cursor.execute("DELETE FROM contacts WHERE id = %s", (message_id,))
        connection.commit()
        
        app.logger.info(f"Successfully deleted message {message_id}")
        flash("Message deleted successfully.", "success")

    except mysql.connector.Error as err:
        app.logger.error(f"Database error in delete_message: {err}")
        flash("An error occurred while deleting the message.", "error")
        
    except Exception as e:
        app.logger.error(f"Unexpected error in delete_message: {e}")
        flash("An unexpected error occurred.", "error")
        
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'connection' in locals():
            connection.close()
            
    return redirect(url_for('admin_chat'))





# Create a message queue for notifications
message_queue = queue.Queue()

def send_email_notification(name, email, phone, message):
    try:
        msg = MIMEMultipart()
        msg['From'] = SMTP_USERNAME
        msg['To'] = SMTP_USERNAME
        msg['Subject'] = f'New Contact Form Message from {name}'
        
        body = f"""
        New message received from the contact form:
        
        Name: {name}
        Email: {email}
        Phone: {phone if phone else 'Not provided'}
        
        Message:
        {message}
        """
        
        msg.attach(MIMEText(body, 'plain'))
        
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(SMTP_USERNAME, SMTP_PASSWORD)
        server.send_message(msg)
        server.quit()
        
        app.logger.info(f"Email notification sent successfully for message from {name}")
        return True
        
    except Exception as e:
        app.logger.error(f"Error sending email notification: {e}")
        return False


@app.route('/admin/notifications/stream')
def notification_stream():
    def generate():
        while True:
            try:
                notification = message_queue.get(timeout=20)
                yield f"data: {json.dumps(notification)}\n\n"
            except queue.Empty:
                yield ": keepalive\n\n"
    
    return Response(
        stream_with_context(generate()),
        mimetype='text/event-stream',
        headers={'Cache-Control': 'no-cache',
                'Transfer-Encoding': 'chunked'}
    )

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>chat--system>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


  





if __name__ == '__main__':
    # Create required directories
    for directory in [LOG_DIR]:
        directory.mkdir(exist_ok=True, parents=True)
        
    # Set development mode from environment variable
    debug_mode = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'
    
   
    
    port = int(os.getenv('FLASK_PORT', '80'))
    
    # Get host from environment variable with fallback to localhost
    host = os.getenv('FLASK_HOST', '0.0.0.0')
    
    app.run(host=host, port=port, debug=debug_mode)
    
    try:
        app.run(host=host, port=port, debug=debug_mode)
    except PermissionError:
        print("Error: Permission denied when trying to bind to port 80")
        print("To run on port 80, you need root/administrator privileges.")
        print("Try one of the following:")
        print("1. Run the script with sudo (Linux/Mac): sudo python your_script.py")
        print("2. Run as administrator (Windows)")
        print("3. Use a port number above 1024 (e.g., 8080) if you don't have admin privileges")
        sys.exit(1)

from werkzeug.security import generate_password_hash

# Replace 'your_admin_password' with the actual password you want to use
admin_password = 'P@v@N!sD0c@2024'
hashed_password = generate_password_hash(admin_password)

print(f"Hashed password: {hashed_password}")